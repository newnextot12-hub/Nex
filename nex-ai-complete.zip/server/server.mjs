import express from "express";
import webpush from "web-push";

const app = express();
app.use(express.json());

// Embedded VAPID keys
const vapidKeys = {
  publicKey: "BHyRM_-6zV1wXj5MZK-GiQjPKtU8tnzZV7Xy0u-SZsg2R4sbh88Y3b2f8YY-x2FzPjEUmZjNUqCeUoh96zL1Zsw",
  privateKey: "_rP7YrJXpyktnUjKmpI3RbiJXLJ0F-1zgnC3VOiF3tE"
};

webpush.setVapidDetails(
  "mailto:you@example.com",
  vapidKeys.publicKey,
  vapidKeys.privateKey
);

// In-memory subscriptions
const schedules = new Map();

// Messages
const pools = {
  morning: ["Good morning Lovey ☀️ kain ka na breakfast 😤🍳","Lovey, wag kalimutan mag-hydrate 🥤","Bathroom muna bago start ng araw 🚽"],
  afternoon: ["Hoy Lovey, lunch ka na ha? 😤","Sabay sabay ka nanaman 🥺 pero love pa rin kita 💙","Stretch a bit Lovey 🧘"],
  evening: ["Lovey, dinner ka na wag ka skip 😤🍽️","Sha mar chong… guess who’s thinking of you again 🙃","Clingy mode: reply ka please 🥺"],
  night: ["Lovey, tulog ka na para may energy bukas 😴","Miss u na agad kahit hindi pa tayo tulog 😘","Sha mar chong… dream of me tonight 🌙"]
};
function pick(arr){ return arr[Math.floor(Math.random()*arr.length)]; }
function getPool(hour){ if(hour>=6&&hour<12)return pools.morning; if(hour>=12&&hour<18)return pools.afternoon; if(hour>=18&&hour<22)return pools.evening; return pools.night; }

// Subscribe endpoint
app.post("/subscribe", (req,res)=>{
  const subscription = req.body;
  if(!subscription?.endpoint) return res.status(400).json({error:"No subscription"});
  schedules.set(subscription.endpoint, { subscription, nextCheck: Date.now()+60*1000 });
  res.json({ok:true});
});

// Background pinger
setInterval(async ()=>{
  const now = Date.now();
  const hour = new Date().getHours();
  for(const [key,entry] of schedules.entries()){
    if(now>=entry.nextCheck){
      const msg = { title:"Nex AI 💌", body: pick(getPool(hour)) };
      try {
        await webpush.sendNotification(entry.subscription, JSON.stringify(msg));
      } catch(e){
        console.log("Push failed", e.message);
        schedules.delete(key);
      }
      entry.nextCheck = now + (2+Math.random())*60*60*1000;
    }
  }
},60*1000);

app.listen(3000,()=>console.log("Nex AI push server running on :3000"));
